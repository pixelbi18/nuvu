export const environment = {
  production: true,

  urlBaseServicio : 'https://ansv.gov.co/rest/escuela',
  authorization: 'Basic YWRtaW4ucmVzdDAxOm5nJWgmLUU0a1gkRA==',
  baseUrl : 'https://ansv.gov.co/',

};
