/* eslint-disable @typescript-eslint/member-ordering */
/* eslint-disable @typescript-eslint/naming-convention */
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { Entidadoautoridad, Escuela, TipoContenido, TipoUsuario, Titulo } from '../interfaces/interfaces';
import { DataLocalService } from '../services/data-local.service';

// Definimos unas constantes, una tomada del enviroment y la otra la cabecera trasnversal a todos los consumos de los servicios
const urlListaEventos = environment.urlBaseServicio;
const authorization = environment.authorization;


const token = '';



/** @todo se debe colocar la cabecera de seguridad del servicio */

const header = {
  'Access-Control-Allow-Headers': '*',
  'Access-Control-Allow-Origin': '*',
  'Content-Type': 'application/json',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS, PATCH',
  'Cache-Control': 'no-cache',
  // eslint-disable-next-line quote-props
  'Authorization' : authorization
};

const httpOptions = new HttpHeaders(header);

@Injectable({
  providedIn: 'root'
})


export class EventosService {

  // Inyectamos la libreria que importada en appmodule.ts
  constructor(  private http: HttpClient,
                public datalocalService: DataLocalService

    ) {



  }

   /**
    * Creamos el servicio generico para ejecutar los servicios, se usa el docorador <T> que sera por cada interface de forma dinamica
    */

   private ejecutarQuery<T>( endpoint: string, queryParams: string = '') {


    console.log('HEADER', header);

    try {
      endpoint = urlListaEventos + endpoint;
      console.log('endpoint', endpoint);

      return this.http.get<T>(endpoint, {headers : httpOptions});
    } catch (error) {
      console.error('Error Status: '+error.status);
      console.error('Error Error: '+error.error); // Error message as string
      console.error('Error Header: '+error.headers);
    }




   }

  private ejecutarQueryPost<T>( endpoint: string, queryParams: string = '') {


    console.log('HEADER', header);

    const httpOptions2 = new HttpHeaders(header);

    try {
      endpoint = urlListaEventos + endpoint;
      console.log('endpoint', endpoint);

      return this.http.post<T>(endpoint, {headers : httpOptions2});
    } catch (error) {
      console.error('Error Status: '+error.status);
      console.error('Error Error: '+error.error); // Error message as string
      console.error('Error Header: '+error.headers);
    }
  }

  private ejecutarQueryPut<T>( endpoint: string, queryParams: string = '') {


    console.log('HEADER', header);

    const httpOptions2 = new HttpHeaders(header);

    try {
      endpoint = urlListaEventos + endpoint;
      console.log('endpoint', endpoint);

      return this.http.put<T>(endpoint, {headers : httpOptions2});
    } catch (error) {
      console.error('Error Status: '+error.status);
      console.error('Error Error: '+error.error); // Error message as string
      console.error('Error Header: '+error.headers);
    }
  }



  // REST de servicios de escuela virtual
  getTipoContenido() {
    return this.ejecutarQuery<TipoContenido>('/grupo/tipocontenido');
  }

  getEntidadoautoridad() {
    return this.ejecutarQuery<Entidadoautoridad>('/grupo/entidadoautoridad');
  }

  getTipousuario() {
    return this.ejecutarQuery<TipoUsuario>('/filtro/tipousuario');
  }

  getTitulo() {
    return this.ejecutarQuery<Titulo>('/filtro/titulo');
  }

  getEscuela(filtro){
    console.log('FILTRO ESCUELA => ', filtro);
    return this.ejecutarQuery<Escuela>(filtro);
  }


}
