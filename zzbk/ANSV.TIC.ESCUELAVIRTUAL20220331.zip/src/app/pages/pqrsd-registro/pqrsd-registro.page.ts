import { Component, OnInit } from '@angular/core';

import * as paises from '../../../assets/json/paises.json';
import * as departamentos from '../../../assets/json/departamentos.json';
import * as departamentosExtranjeros from '../../../assets/json/departamentosExtranjeros.json';
import * as ciudades from '../../../assets/json/ciudades.json';


@Component({
  selector: 'app-pqrsd-registro',
  templateUrl: './pqrsd-registro.page.html',
  styleUrls: ['./pqrsd-registro.page.scss'],
})
export class PqrsdRegistroPage implements OnInit {
  todo = {
    anonimo: '',
    asunto: '',
    nombre: '',
    tipoDocumento:'',
    documento:'',
    respuesta:'',
    email:'',
    direccion:'',
    barrioVeredaCorregimiento:'',
    pais: [],
    departamento: [],
    ciudad: [],
    numeroContacto:'',
    mensaje:'',
    adjunto:'',
  };

  paises = '';
  departamentos = '';
  departamentosTemporal = '';
  departamentosExtranjeros = '';
  ciudades = '';
  ciudadesTemporal = '';
  asuntoSelected = '';
/*
  department =[
    {value:0,label:'Animales'},
    {value:1,label:'Frutas'}
  ];
  $scope.deps = [];
  var animals = [{value:0,label:'Perro',}, {value:1,label:'Gato'}];
  var fruits = [{value:0,label:'Platano'}, {value:1,label:'Manzana'}];
  var arrays = [animals, fruits];
  ...
  $scope.selectChanged = function() {
    $scope.deps = arrays[$scope.select1];
  }
  */



  constructor() { }

  ngOnInit() {
    this.readJsonPaises();
    this.readJsonDepartamentos();
    this.readJsonDepartamentosExtranjeros();
    this.readJsonCiudades();
  }

  asuntoCambio(e){
    this.asuntoSelected = e.detail.value;

  }


  readJsonPaises(){
    fetch('../../../assets/json/paises.json').then(res=>res.json()).then(json=>{
        this.paises = json;
    });
  }
  readJsonDepartamentos(){
    fetch('../../../assets/json/departamentos.json').then(res=>res.json()).then(json=>{
      this.departamentosTemporal = json;
    });
  }
  readJsonDepartamentosExtranjeros(){
    fetch('../../../assets/json/departamentosExtranjeros.json').then(res=>res.json()).then(json=>{
      this.departamentosExtranjeros = json;
    });
  }

  readJsonCiudades(){
    fetch('../../../assets/json/ciudades.json').then(res=>res.json()).then(json=>{
      this.ciudadesTemporal = json;
    });
  }

  cambiarDepartamento(e){
    this.departamentos = '';
    this.todo.departamento = [];

    if ( Number(e.detail.value) === 170 ){
      this.departamentos = this.departamentosTemporal;

    } else {
      this.departamentos = this.departamentosExtranjeros;
    }

  }

  cambiarCiudad(e){
    this.ciudades = '';
    this.todo.ciudad = [];
    if(e.detail.value.length > 0){

      const myJson = JSON.parse(JSON.stringify(this.ciudadesTemporal));
      const resultado = myJson.filter(val=> val.value === e.detail.value );
      this.ciudades = resultado[0].ciudades;

    }
  }




}
