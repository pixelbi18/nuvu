import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { PqrsdRegistroPageRoutingModule } from './pqrsd-registro-routing.module';

import { PqrsdRegistroPage } from './pqrsd-registro.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    PqrsdRegistroPageRoutingModule
  ],
  declarations: [PqrsdRegistroPage]
})
export class PqrsdRegistroPageModule {}
