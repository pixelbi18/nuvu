import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { PqrsdConsultaPageRoutingModule } from './pqrsd-consulta-routing.module';

import { PqrsdConsultaPage } from './pqrsd-consulta.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    PqrsdConsultaPageRoutingModule
  ],
  declarations: [PqrsdConsultaPage]
})
export class PqrsdConsultaPageModule {}
