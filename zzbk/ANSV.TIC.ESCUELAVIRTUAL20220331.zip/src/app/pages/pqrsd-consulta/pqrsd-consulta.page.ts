import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pqrsd-consulta',
  templateUrl: './pqrsd-consulta.page.html',
  styleUrls: ['./pqrsd-consulta.page.scss'],
})
export class PqrsdConsultaPage implements OnInit {

  todo = {
    idRadicado: '',
    codever: ''
  };

  constructor() { }

  ngOnInit() {
  }

  logForm() {
    console.log(this.todo);
  }

}
