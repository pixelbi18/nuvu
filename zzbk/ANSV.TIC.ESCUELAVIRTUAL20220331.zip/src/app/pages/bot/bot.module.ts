import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { BotPageRoutingModule } from './bot-routing.module';

import { BotPage } from './bot.page';

import { PdfViewerModule } from 'ng2-pdf-viewer';


@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    BotPageRoutingModule,
    PdfViewerModule
  ],
  declarations: [BotPage],
  providers: [
  ]
})
export class BotPageModule {}
