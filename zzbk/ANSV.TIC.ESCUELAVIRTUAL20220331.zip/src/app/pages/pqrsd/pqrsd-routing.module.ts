import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { PqrsdPage } from './pqrsd.page';

const routes: Routes = [

  {
    path: 'tabs',
    component: PqrsdPage,
    children: [
      {
        path: 'registro',
        loadChildren: () => import('../pqrsd-registro/pqrsd-registro.module').then(m => m.PqrsdRegistroPageModule)
      },
      {
        path: 'consulta',
        loadChildren: () => import('../pqrsd-consulta/pqrsd-consulta.module').then(m => m.PqrsdConsultaPageModule)
      },
      {
        path: '',
        redirectTo: 'tabs/registro',
        pathMatch: 'full'
      }
    ]
  },
  {
    path: '',
    redirectTo: 'tabs/registro',
    pathMatch: 'full'
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class PqrsdPageRoutingModule {}
